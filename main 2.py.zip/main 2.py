"""
Developer: Winifred Halm De-Souza
Date: 13 May 2023
Purpose: This application prints the message "Hello, World!" to the console.
"""

# Print the message "Hello, World!"
print("Hello, World!")
